import Image from "next/image";
import AutomobilePage from "./Automobile/page";

export default function Home() {
  return (
    <>
    <h2 className='text-gray-500 hover:text-blue-700 font-semibold px-10' style={{ marginTop: '20px' }}>Welcome to Next Home Page</h2>
    </>
  );
}
