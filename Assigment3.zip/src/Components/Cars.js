import React from 'react';
import Image from 'next/image';

function LatestModel(){

    const cars = [
        {
          id: 1,
          name: 'Tesla Model S',
          brand: 'Tesla',
          year: 2025,
          imgSrc: 'https://www.tesla.com/sites/default/files/modelsx-new/social/model-s-hero-social.jpg'
        },
        {
          id: 2,
          name: 'Ford Mustang Mach-E',
          brand: 'Ford',
          year: 2025,
          imgSrc: 'https://www.ford.ca/is/image/content/dam/na/ford/en_ca/images/mach-e/2025/dm/2025_Mustang_Mach-E_Premium_Sport_Appearance_Package_Gallery_01.tif?croppathe=1_16x7&wid=1920&fmt=webp'
        },
        {
          id: 3,
          name: 'BMW i4',
          brand: 'BMW',
          year: 2025,
          imgSrc: 'https://vehicle-images.dealerinspire.com/f6b3-11002228/WBY43HD08SFU15518/ad312fe5281391b92889fbbe6d6d75e6.jpg'
        },
        {
          id: 4,
          name: 'Audi Q4 e-tron',
          brand: 'Audi',
          year: 2025,
          imgSrc: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQX4oFeM-abfiP-50HtcHLkFJqkERo--V-skg&s'
        },
        {
          id: 5,
          name: 'Mercedes EQS',
          brand: 'Mercedes-Benz',
          year: 2025,
          imgSrc: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNfV4SyjhVokzkls2huXz-6yxoB8zgi1TD4q6Y-zNcFsXhL4kQVyZu6lR-0FTByTHUhF0&usqp=CAU'
        },
        {
          id: 6,
          name: 'Porsche Taycan',
          brand: 'Porsche',
          year: 2025,
          imgSrc: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Porsche_Taycan_4S_IMG_3526.jpg/1200px-Porsche_Taycan_4S_IMG_3526.jpg'
        }
      ];

      return (
        <ul style={{ padding: '0', listStyleType: 'none' }}>
          {cars.map((car) => (
            <li key={car.id} style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
              <Image 
                src={car.imgSrc} 
                alt={car.name} 
                width={150} 
                height={100} 
                style={{ marginRight: '20px', borderRadius: '8px' }} 
              />
              <div>
                <strong>{car.name}</strong> ({car.brand} - {car.year})
              </div>
            </li>
          ))}
        </ul>
      );
}
export default LatestModel