// next.config.js

module.exports = {
    images: {
      domains: [
        'www.tesla.com',
        'media.ford.com',
        'www.bmwusa.com',
        'www.audiusa.com',
        'media.mercedes-benz.com',
        'www.porsche.com',
        'www.ford.ca',
        'vehicle-images.dealerinspire.com',
        'www.encrypted-tbn0.gstatic.com',
        'encrypted-tbn0.gstatic.com',
        'upload.wikimedia.org'
      ],
    },
  }
  